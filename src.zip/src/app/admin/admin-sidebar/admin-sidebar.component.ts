import { Component } from '@angular/core';
import { Drawer } from 'flowbite';

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrl: './admin-sidebar.component.css'
})
export class AdminSidebarComponent {

  ngOnInit(): void {
    // Initialisation du comportement d'ouverture/fermeture de la barre latérale
    const $sidebarElement = document.getElementById('logo-sidebar');
    const sidebarOptions = {
      backdropClasses: 'bg-gray-900 bg-opacity-50 dark:bg-opacity-80 fixed inset-0 z-30',
    };
    const drawer = new Drawer($sidebarElement, sidebarOptions);
  }

}
