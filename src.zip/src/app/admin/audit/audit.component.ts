import { Component, OnInit } from '@angular/core';
import { AuditService } from '../../services/audit.service';

export interface AuditDTO {
  action: string;
  description: string;
  timestamp: Date;
}

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.css']
})
export class AuditComponent implements OnInit {
  audits: AuditDTO[] = [];
  startDate: string = '';
  endDate: string = '';

  constructor(private auditService: AuditService) { }

  ngOnInit(): void {
    // Définir les dates par défaut (aujourd'hui)
    const today = new Date().toISOString().slice(0, 10);
    this.startDate = today;
    this.endDate = today;

    // Appeler la méthode pour afficher les audits d'aujourd'hui
    this.getAuditsByDateRange();
  }

  getAuditsByDateRange(): void {
    this.auditService.getAuditsByDateRange(this.startDate, this.endDate).subscribe(
      audits => this.audits = audits,
      error => console.error('Error fetching audits by date range:', error)
    );
  }
}