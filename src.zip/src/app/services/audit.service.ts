import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


export interface AuditDTO {
 
  action: string;
  description: string;
  timestamp: Date;
  // Ajoutez d'autres propriétés si nécessaire
}

@Injectable({
  providedIn: 'root'
})
export class AuditService {
  private apiUrl = 'http://localhost:8080/api/audits';

  constructor(private http: HttpClient) { }

  getAuditsByDay(date: string): Observable<AuditDTO[]> {
    return this.http.get<AuditDTO[]>(`${this.apiUrl}/day/${date}`);
  }

  getAuditsByWeek(date: string): Observable<AuditDTO[]> {
    return this.http.get<AuditDTO[]>(`${this.apiUrl}/week/${date}`);
  }

  getAuditsByMonth(date: string): Observable<AuditDTO[]> {
    return this.http.get<AuditDTO[]>(`${this.apiUrl}/month/${date}`);
  }

  getAuditsByDateRange(startDate: string, endDate: string): Observable<AuditDTO[]> {
    const url = `${this.apiUrl}/range?startDate=${startDate}&endDate=${endDate}`;
    return this.http.get<AuditDTO[]>(url);
  }
}