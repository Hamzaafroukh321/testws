import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loginUrl = 'http://localhost:8080/api/auth/login';
  private tokenKey = 'token';
  private roleKey = 'role';

  constructor(private http: HttpClient) { }

  login(email: string, password: string): Observable<any> {
    const loginRequest = { email, password };
    return this.http.post<any>(this.loginUrl, loginRequest).pipe(
      tap(response => {
        localStorage.setItem(this.tokenKey, response.token);
        localStorage.setItem('firstTime', response.firstTime.toString());
        localStorage.setItem('permissions', JSON.stringify(response.permissions));
        localStorage.setItem('roles', JSON.stringify(response.roles));
        // matricule de l'utilisateur
        localStorage.setItem('matricule', response.matricule);
      })
    );
  }

  getRole(): string | null {
    return localStorage.getItem(this.roleKey);
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem(this.tokenKey);
  }
}