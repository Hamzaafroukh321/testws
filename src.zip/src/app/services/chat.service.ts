import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';
import { catchError, tap } from 'rxjs/operators';

// Modèle ChatMessageDTO
export class ChatMessageDTO {
  constructor(
    public id: number,
    public senderId: number,
    public recipientId: number,
    public content: string,
    public timestamp: Date,
    public isPrivate: boolean
  ) {}
}

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private apiUrl = '/api/chat';
  private socket$: WebSocketSubject<any>;
  private messagesSubject = new Subject<ChatMessageDTO>();
  public messages$ = this.messagesSubject.asObservable();

  constructor(private http: HttpClient) {
    this.socket$ = webSocket(`ws://localhost:8080/chat/messages`);
    this.socket$.subscribe(
      message => this.messagesSubject.next(message),
      error => console.error(error)
    );
  }

  sendMessage(message: ChatMessageDTO): Observable<ChatMessageDTO> {
    this.socket$.next(message);
    return this.http.post<ChatMessageDTO>(`${this.apiUrl}/messages`, message);
  }

  sendPrivateMessage(message: ChatMessageDTO): Observable<ChatMessageDTO> {
    this.socket$.next(message);
    return this.http.post<ChatMessageDTO>(`${this.apiUrl}/private-messages`, message);
  }

  getChatHistory(senderId: number, recipientId: number, page: number, pageSize: number): Observable<any> {
    const params = { senderId, recipientId, page, pageSize };
    return this.http.get<any>(`${this.apiUrl}/history`, { params });
  }

  getPrivateConversations(userId: number): Observable<ChatMessageDTO[]> {
    const params = { userId };
    return this.http.get<ChatMessageDTO[]>(`${this.apiUrl}/private-conversations`, { params });
  }

  closeSocket() {
    this.socket$.complete();
  }
}